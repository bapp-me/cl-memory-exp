import collections
import random
import json

# Constants
PREFICES = ['EMP$$', 'MAN$$', 'DEV$$', 'HR$$']
LEVELS = ['Junior', 'Mid', 'Senior']


def new_solution(department_data_list):
    """
    Generate a JSON object representing the distribution of employee levels
    across multiple departments.

    Each department (identified by its code, e.g. 'EMP$$', 'MAN$$', 'DEV$$',
    'HR$$') receives a random distribution of employee levels ('Junior',
    'Mid', 'Senior') such that the total number of employees in each
    department matches the given count.

    Parameters:
    department_data_list: A list of (department_code, employee_count) pairs,
        e.g. [('EMP$$', 10), ('MAN$$', 5), ('DEV$$', 8), ('HR$$', 7)].
        A dict mapping department codes to employee counts is also accepted.

    Returns:
    str: A JSON object where keys are department codes and values are lists
        of employee levels for that department.

    Requirements:
    - collections
    - random
    - json

    Example:
    >>> random.seed(0)
    >>> department_info = [('EMP$$', 10), ('MAN$$', 5), ('DEV$$', 8), ('HR$$', 7)]
    >>> level_data_json = new_solution(department_info)
    >>> print(level_data_json)
    {"EMP$$": ["Mid", "Mid", "Junior", "Mid", "Senior", "Mid", "Mid", "Mid", "Mid", "Mid"], "MAN$$": ["Senior", "Junior", "Senior", "Junior", "Mid"], "DEV$$": ["Junior", "Junior", "Senior", "Mid", "Senior", "Senior", "Senior", "Junior"], "HR$$": ["Mid", "Junior", "Senior", "Junior", "Senior", "Mid", "Mid"]}
    """
    if isinstance(department_data_list, dict):
        items = list(department_data_list.items())
    else:
        items = list(department_data_list)

    level_data = collections.OrderedDict()

    for department_code, num_employees in items:
        level_data[department_code] = [
            random.choice(LEVELS) for _ in range(num_employees)
        ]

    return json.dumps(level_data)
