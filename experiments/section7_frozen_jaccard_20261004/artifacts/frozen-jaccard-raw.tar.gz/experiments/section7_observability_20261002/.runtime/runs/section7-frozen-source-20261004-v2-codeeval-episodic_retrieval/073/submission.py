import pandas as pd
import matplotlib.pyplot as plt
from collections import defaultdict


def generate_summary_report(transactions):
    """
    Generate a summary report from a list of transaction dictionaries.

    Each transaction is a dict with keys 'date', 'amount', and 'category'.
    The report contains, per category, the total amount spent and the
    average amount per transaction, plus a bar chart of transaction
    counts per category.

    Parameters:
        transactions (list): List of dicts with keys 'date', 'amount', 'category'.

    Returns:
        tuple: (dict, matplotlib.axes.Axes) where the dict maps each category to
               {'total_amount': float, 'average_amount': float, 'transaction_count': int}
               and the Axes object shows the distribution of transaction counts
               across categories.
    """
    if not transactions:
        fig, ax = plt.subplots()
        ax.set_title("Transaction Counts by Category")
        ax.set_xlabel("Category")
        ax.set_ylabel("Transaction Count")
        return {}, ax

    category_totals = defaultdict(float)
    category_counts = defaultdict(int)

    for txn in transactions:
        category = txn['category']
        category_totals[category] += txn['amount']
        category_counts[category] += 1

    report = {}
    for category in sorted(category_totals.keys()):
        count = category_counts[category]
        report[category] = {
            'total_amount': category_totals[category],
            'average_amount': category_totals[category] / count,
            'transaction_count': count,
        }

    fig, ax = plt.subplots()
    categories = sorted(category_counts.keys())
    counts = [category_counts[c] for c in categories]
    ax.bar(categories, counts)
    ax.set_title("Transaction Counts by Category")
    ax.set_xlabel("Category")
    ax.set_ylabel("Transaction Count")

    return report, ax
