from collections import Counter
import itertools
import string


def aggregate_frequencies(words: list) -> dict:
    """
    Create a dictionary where each key is a two-letter combination of the
    lowercase English alphabets, and the value is a list of frequencies of
    this combination across all words. If a combination does not appear in
    a word, its frequency for that word is 0.

    Requirements:
    - collections.Counter
    - itertools
    - string

    Parameters:
    - words (list): A list of input strings containing alphabetic characters.

    Returns:
    - dict: A dictionary with keys as two-letter alphabet combinations and
      values as lists of their counts across all input words (one entry per word).

    Example:
    >>> aggregate_frequencies(['abc', 'aab'])['ab']
    [1, 1]
    >>> aggregate_frequencies(['abc', 'aab'])['aa']
    [0, 1]
    """
    # Count consecutive two-letter combinations within each word
    per_word_counts = [Counter(zip(word, word[1:])) for word in words]

    # Build the result dictionary for every two-letter combination of the
    # lowercase alphabet, listing its frequency in each word (0 if absent).
    return {
        a + b: [counts[(a, b)] for counts in per_word_counts]
        for a, b in itertools.product(string.ascii_lowercase, repeat=2)
    }
