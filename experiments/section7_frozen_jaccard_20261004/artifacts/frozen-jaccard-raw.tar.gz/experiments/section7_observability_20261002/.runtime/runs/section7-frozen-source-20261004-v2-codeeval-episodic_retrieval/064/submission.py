import pandas as pd
import statsmodels.api as sm


def new_solution(df: pd.DataFrame, height: int, weight: int, columns: list) -> dict:
    """
    Performs an OLS linear regression for each dataset in the provided DataFrame.
    The DataFrame is split by the unique values of the 'DatasetID' column. For each
    dataset, rows are filtered where the value in the second column of 'columns' is
    greater than 'height' and the value in the third column is less than 'weight'.
    The first column in 'columns' is used as the dependent variable / target (y),
    and the rest as independent variables (X) in the regression.

    If the DataFrame is empty, an empty dict is returned. If for a specific dataset
    no rows match the conditions (or the dataset subset is empty), None is returned
    for that dataset.

    Parameters:
    - df (pd.DataFrame): The DataFrame to analyze, containing a 'DatasetID' column.
    - height (int): The threshold to filter rows based on the second column in 'columns'.
    - weight (int): The threshold to filter rows based on the third column in 'columns'.
    - columns (list of str): A list of column names to use, where the first is the
      dependent variable.

    Returns:
    - dict: A dictionary where keys are the 'DatasetID' values and values are the
      OLS regression results (sm.regression.linear_model.RegressionResultsWrapper)
      for each dataset, or None if no rows meet the criteria for that dataset.

    Requirements:
    - pandas
    - statsmodels
    """
    if df.empty:
        return {}

    results = {}
    for dataset_id, subset_df in df.groupby('DatasetID'):
        filtered = subset_df[
            (subset_df[columns[1]] > height) & (subset_df[columns[2]] < weight)
        ]
        if filtered.empty:
            results[dataset_id] = None
            continue
        y = filtered[columns[0]]
        X = filtered[columns[1:]]
        model = sm.OLS(y, X).fit()
        results[dataset_id] = model

    return results
