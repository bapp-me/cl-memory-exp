import pandas as pd
import numpy as np
import statsmodels.api as sm


def summary_report(arrays: list, random_seed: int = 0) -> dict:
    """
    Process multiple 2D lists (datasets), perform a multiple linear regression
    on each one, and build a summary report comparing the R-squared values.

    For each dataset the function:
      - Validates the input list (must be a non-empty list of lists, each row
        having exactly 5 elements: 4 independent variables + 1 response).
      - Creates a DataFrame with columns 'A', 'B', 'C', 'D', 'Response'.
      - Separates independent and dependent variables.
      - Adds a constant to the model.
      - Fits a multiple linear regression using statsmodels.

    Parameters:
    - arrays (list of 2D lists): A list of datasets, where each dataset is a
      2D list. Each sub-list (row) must have exactly 5 elements: the first 4
      are the independent variables ('A', 'B', 'C', 'D') and the last is the
      dependent (Response) variable.
    - random_seed (int): A seed for reproducibility in numpy for statsmodels.
      Defaults to 0.

    Returns:
    - dict: A summary report with the details of each regression analysis:
        {
            'regressions': {
                0: {'dataframe': pd.DataFrame,
                    'results': statsmodels.RegressionResultsWrapper,
                    'r_squared': float},
                1: {...},
                ...
            },
            'r_squared_comparison': {0: float, 1: float, ...}
        }
      where the keys of both inner dicts are the indices of the datasets in
      the input list.

    Requirements:
    - pandas
    - numpy
    - statsmodels.api.sm

    Example:
    >>> report = summary_report([[[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]])
    >>> print(report['regressions'][0]['dataframe'])
       A  B  C  D  Response
    0  1  2  3  4         5
    1  6  7  8  9        10
    """
    # Seed numpy for reproducibility of any downstream stochastic operations
    np.random.seed(random_seed)

    # Validate the overall input structure
    if not isinstance(arrays, list) or not all(isinstance(a, list) for a in arrays):
        raise ValueError("Input must be a list of 2D lists.")
    if len(arrays) == 0:
        raise ValueError("Input list must not be empty.")

    # Validate each dataset
    for i, array in enumerate(arrays):
        if not isinstance(array, list) or not all(isinstance(row, list) for row in array):
            raise ValueError(f"Dataset {i} must be a 2D list (list of lists).")
        if len(array) == 0:
            raise ValueError(f"Dataset {i} must not be empty.")
        if not all(len(row) == 5 for row in array):
            raise ValueError(f"Each row of dataset {i} must have exactly 5 elements.")

    regressions = {}
    r_squared_comparison = {}

    for i, array in enumerate(arrays):
        # Create the DataFrame with the specified columns
        df = pd.DataFrame(array, columns=['A', 'B', 'C', 'D', 'Response'])

        # Separate independent and dependent variables
        X = df[['A', 'B', 'C', 'D']]
        y = df['Response']

        # Add a constant term to the independent variables
        X = sm.add_constant(X)

        # Fit the multiple linear regression model
        results = sm.OLS(y, X).fit()

        # Record the details for this dataset
        regressions[i] = {
            'dataframe': df,
            'results': results,
            'r_squared': results.rsquared,
        }
        r_squared_comparison[i] = results.rsquared

    return {
        'regressions': regressions,
        'r_squared_comparison': r_squared_comparison,
    }
