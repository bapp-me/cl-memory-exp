import pandas as pd
from collections import Counter


def overall_combination_frequency(*dfs):
    """
    Given multiple DataFrames, each containing a set of items in rows, calculate the
    overall frequency of combinations of elements across all DataFrames.

    The function adds a 'combination' column to each DataFrame, which is the
    combination (tuple) of items in each row. It then calculates the frequency of
    each combination across all DataFrames and returns a dictionary containing the
    frequency of all combinations.

    Parameters:
    - *dfs (pandas.DataFrame): One or more input DataFrames whose rows contain items
      (e.g., columns 'item1', 'item2', 'item3', 'item4', 'item5').

    Returns:
    - dict: A dictionary containing the frequency of all combinations across all
      DataFrames, where keys are tuples of items and values are their counts.

    Requirements:
    - pandas
    - collections

    Example:
    >>> df1 = pd.DataFrame({'item1': ['a', 'b', 'a'], 'item2': ['b', 'c', 'b'], 'item3': ['c', 'd', 'c'], 'item4': ['d', 'e', 'd'], 'item5': ['e', 'f', 'e']})
    >>> df2 = pd.DataFrame({'item1': ['a', 'b'], 'item2': ['b', 'c'], 'item3': ['c', 'd'], 'item4': ['d', 'e'], 'item5': ['e', 'f']})
    >>> overall_combination_frequency(df1, df2)
    {('a', 'b', 'c', 'd', 'e'): 3, ('b', 'c', 'd', 'e', 'f'): 2}
    """
    all_combinations = []

    for df in dfs:
        combinations = [tuple(row) for row in df.values]
        df['combination'] = combinations
        all_combinations.extend(combinations)

    return dict(Counter(all_combinations))
