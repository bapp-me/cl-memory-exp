import numpy as np
import random
from scipy import stats


def new_task_func(dict_of_lists, size=5, seed=0):
    """
    Calculate the overall mean, median, and mode of all the values across
    all lists in a dictionary. If a list is empty, fill it with SIZE
    (default: 5) random integers between 0 and 100 before calculating.

    Parameters:
    dict_of_lists (dict): A dictionary where each key maps to a list of integers.
    size (int, Optional): The number of random integers to generate for empty lists. Default is 5.
    seed (int, Optional): Seed value for random number generation. Default is 0.

    Returns:
    dict: A dictionary with the overall mean, median, and mode of all values.

    Requirements:
    - numpy
    - random
    - scipy.stats

    Example:
    >>> new_task_func({'a': [1, 2, 3], 'b': [], 'c': [4, 5, 6]})
    {'mean': 23.454545454545453, 'median': 5.0, 'mode': array([5])}
    """
    # Seed the RNG for reproducibility
    random.seed(seed)

    # Collect all values, filling empty lists with random integers
    all_values = []
    for key, lst in dict_of_lists.items():
        if len(lst) == 0:
            lst = [random.randint(0, 100) for _ in range(size)]
        all_values.extend(lst)

    # Compute the overall statistics
    mean = np.mean(all_values)
    median = np.median(all_values)
    mode = stats.mode(all_values).mode

    return {'mean': mean, 'median': median, 'mode': mode}
