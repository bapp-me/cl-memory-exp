import pandas as pd
import regex as re
from sklearn.feature_extraction.text import CountVectorizer


def combined_dtm(documents):
    """
    Create a combined document-term matrix for a list of documents.

    Each document is processed individually: it is split into sentences
    (separated by periods, empty sentences ignored), and a document-term
    matrix is built for those sentences with CountVectorizer. All the
    per-document matrices are then concatenated horizontally to form a
    single combined matrix of term frequencies across all documents.

    Parameters:
    - documents (list): A list of strings, each containing one or more
      sentences separated by periods.

    Returns:
    - DataFrame: A pandas DataFrame with the combined document-term matrix.
      Each row corresponds to a sentence from the original documents and
      the column names are adapted from the vectorizer feature names.

    Requirements:
    - pandas
    - regex
    - sklearn.feature_extraction.text.CountVectorizer
    """
    dtms = []
    for doc in documents:
        # Split the document into sentences on periods, ignoring empty ones
        sentences = [sentence.strip() for sentence in re.split(r'\.', doc) if sentence.strip()]
        if not sentences:
            continue

        # Build the document-term matrix for this document individually
        vectorizer = CountVectorizer()
        dtm = vectorizer.fit_transform(sentences)
        dtms.append(pd.DataFrame(dtm.toarray(), columns=vectorizer.get_feature_names_out()))

    # No valid text in any document
    if not dtms:
        return pd.DataFrame()

    # Concatenate all per-document matrices horizontally; missing counts
    # (when documents have different numbers of sentences) are zeros
    combined = pd.concat(dtms, axis=1).fillna(0).astype(int)
    return combined
