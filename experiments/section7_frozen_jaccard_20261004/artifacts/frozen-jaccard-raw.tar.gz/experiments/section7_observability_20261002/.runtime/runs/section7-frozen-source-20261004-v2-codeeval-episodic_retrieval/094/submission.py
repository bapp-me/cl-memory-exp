import numpy as np
import bisect
import statistics
import matplotlib.pyplot as plt


def new_task_func(data_list, value):
    """
    Given a list of sublists of numerical data, for each sublist identify values greater
    than that sublist's average, and count how many values in each sublist are greater
    than a specified value. Then plot a histogram of the sorted numbers from all sublists
    combined.

    Parameters:
        data_list (list): A list of lists of numerical data.
        value (float): A value to compare against the data in each sublist.

    Returns:
        tuple:
            numpy.ndarray: Combined array of values (across all sublists) that are
                greater than the average of their respective sublist.
            int: Total count of values greater than the specified value across all sublists.

    Note:
        - If data_list is empty or contains only empty sublists, returns an empty
          numpy.ndarray and a count of 0.
    """
    if not data_list:
        plt.figure()
        plt.close()
        return np.array([]), 0

    combined_greater_avg = []
    total_count = 0
    all_values = []

    for sublist in data_list:
        if not sublist:
            continue

        arr = np.array(sublist)
        avg = statistics.mean(sublist)

        # Values in this sublist greater than the sublist's average
        greater_avg = arr[arr > avg]
        combined_greater_avg.extend(greater_avg.tolist())

        # Count values in this sublist greater than the specified value (via bisect)
        sorted_sublist = sorted(sublist)
        count = len(sorted_sublist) - bisect.bisect_right(sorted_sublist, value)
        total_count += count

        all_values.extend(sublist)

    # Plot histogram of the sorted numbers from all sublists combined
    plt.figure()
    plt.hist(sorted(all_values), bins='auto')
    plt.title('Histogram of Sorted Numbers (All Sublists Combined)')
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.close()

    return np.array(combined_greater_avg), total_count
