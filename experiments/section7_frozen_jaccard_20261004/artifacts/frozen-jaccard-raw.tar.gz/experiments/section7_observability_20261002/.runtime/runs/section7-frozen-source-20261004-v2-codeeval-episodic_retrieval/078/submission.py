import numpy as np
from scipy import stats
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt


def new_task_func(list_of_dicts):
    """
    For each dictionary in the given list of dictionaries:
    1. Adds a key 'a' with a value of 1.
    2. Conducts statistical analysis on its values (mean, median, mode), rounding the mean to 2 decimal places.
    3. Normalizes the values using MinMaxScaler to a range of (0, 1).
    4. Plots a histogram of the normalized values, with the title 'Histogram of Normalized Values',
       and x label 'Value' and y label 'Frequency'.

    Finally, aggregates the statistical properties (mean, median, mode) from all dictionaries
    into a single dictionary.

    Parameters:
    list_of_dicts (list): A list of dictionaries, each containing numerical values.

    Returns:
    tuple: A tuple containing:
        - list: The list of processed dictionaries with key 'a' added to each.
        - dict: A dictionary aggregating the statistical properties (mean, median, mode)
                from all dictionaries.
        - list: A list of matplotlib.axes.Axes objects, one histogram plot per dictionary.

    Requirements:
    - numpy
    - scipy
    - sklearn.preprocessing
    - matplotlib.pyplot

    Example:
    >>> processed, aggregated, plots = new_task_func([{'key': 5, 'another_key': 10}])
    >>> processed
    [{'key': 5, 'another_key': 10, 'a': 1}]
    >>> plots[0].get_title()
    'Histogram of Normalized Values'
    """
    processed_dicts = []
    plots = []
    all_means, all_medians, all_modes = [], [], []

    for d in list_of_dicts:
        # 1. Add key 'a' with a value of 1
        d = dict(d)
        d["a"] = 1
        processed_dicts.append(d)

        # 2. Statistical analysis on the values (mean rounded to 2 decimal places)
        values = list(d.values())
        mean_val = round(float(np.mean(values)), 2)
        median_val = float(np.median(values))
        mode_val = stats.mode(np.array(values)).mode

        all_means.append(mean_val)
        all_medians.append(median_val)
        all_modes.append(float(mode_val[0]))

        # 3. Normalize the values using MinMaxScaler to the range (0, 1)
        normalized = MinMaxScaler().fit_transform(
            np.array(values, dtype=float).reshape(-1, 1)
        ).flatten()

        # 4. Plot a histogram of the normalized values
        fig, ax = plt.subplots()
        ax.hist(normalized)
        ax.set_title("Histogram of Normalized Values")
        ax.set_xlabel("Value")
        ax.set_ylabel("Frequency")
        plots.append(ax)

    # Aggregate the statistical properties from all dictionaries
    if not all_means:
        aggregated = {}
    else:
        aggregated = {
            "mean": round(float(np.mean(all_means)), 2),
            "median": float(np.median(all_medians)),
            "mode": stats.mode(np.array(all_modes)).mode,
        }

    return processed_dicts, aggregated, plots
