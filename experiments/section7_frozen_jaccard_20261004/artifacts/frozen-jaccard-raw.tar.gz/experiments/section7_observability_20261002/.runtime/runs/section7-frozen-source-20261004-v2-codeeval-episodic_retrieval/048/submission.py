import collections
import string
import random

def combined_frequency(lengths, seed=0):
    """
    Generate multiple random strings of varying lengths and calculate the
    combined frequency of each character across all generated strings.

    Parameters:
    lengths (list of int): The lengths of the random strings to be generated.
    seed (int, optional): The seed for the random number generator to ensure
        reproducibility. Default is 0.

    Returns:
    dict: A dictionary with the frequency of each character in the combined strings.

    Requirements:
    - collections
    - string
    - random

    Example:
    >>> result = combined_frequency([4, 5], seed=0)
    >>> isinstance(result, dict)  # The result should be a dictionary
    True
    >>> all(key in string.ascii_letters for key in result.keys())  # All keys should be ASCII letters
    True
    >>> sum(result.values()) == sum(lengths)  # Total counts equal total length
    True
    >>> combined_frequency([], seed=0)
    {}
    """
    random.seed(seed)

    combined = ''.join(
        ''.join(random.choice(string.ascii_letters) for _ in range(length))
        for length in lengths
    )

    return dict(collections.Counter(combined))
