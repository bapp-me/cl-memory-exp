import collections
import random
import itertools

ANIMALS = ['Cat', 'Dog', 'Elephant', 'Lion', 'Tiger', 'Bear', 'Giraffe', 'Horse', 'Rabbit', 'Snake', 'Zebra']


def new_task_func(list_of_animal_dicts, max_count=10, seed=0):
    """
    Given a constant list of animals in ANIMALS and a list of dictionaries, each mapping
    people's names to their favorite animal names, reverse each dictionary and count the
    occurrences of each predefined animal name across all groups.

    This function performs two tasks:
    1. It reverses each dictionary in the given list such that the original values (animal
       names) become keys and the original keys (people's names) become lists of values.
       Only values present in the predefined ANIMALS list are kept.
    2. It counts the total occurrences of each predefined animal name across all groups.
       Predefined animals that do not appear in any group receive a deterministic random
       count between 1 and max_count (inclusive), generated with the given seed.

    Parameters:
    list_of_animal_dicts (list): A list of dictionaries, each with keys as names and
                                 values as animal names.
    max_count (int, Optional): A positive integer denoting the maximum random count for
                               absent animals. Default is 10. Must be greater than 0.
    seed (int, Optional): An integer to seed the random number generator. Default is 0.

    Returns:
    tuple: A tuple where the first element is a list of reversed dictionaries and the
           second element is a counter with the total occurrences of each animal name.

    Requirements:
    - collections
    - random
    - itertools
    """
    if max_count <= 0:
        raise ValueError("max_count must be greater than 0")

    random.seed(seed)

    reversed_dicts = []
    total_counter = collections.Counter()

    for animal_dict in list_of_animal_dicts:
        sorted_items = sorted(animal_dict.items(), key=lambda kv: kv[1])
        reversed_dict = {
            animal: [person for person, _ in group]
            for animal, group in itertools.groupby(sorted_items, key=lambda kv: kv[1])
            if animal in ANIMALS
        }
        reversed_dicts.append(reversed_dict)

        # Accumulate total occurrences of each animal across all groups.
        for animal, people in reversed_dict.items():
            total_counter[animal] += len(people)

    # Ensure every predefined animal appears in the counter; animals not present
    # in any group get a deterministic random count between 1 and max_count.
    for animal in ANIMALS:
        if total_counter[animal] == 0:
            total_counter[animal] = random.randint(1, max_count)

    return reversed_dicts, total_counter
