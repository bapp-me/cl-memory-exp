import seaborn as sns
import numpy as np
import pandas as pd


def combined_task(df_list):
    """
    Generates a combined pair plot and covariance matrix from a list of DataFrames.

    Parameters:
    - df_list (list of pandas.DataFrame): A list of DataFrames with only numeric columns.

    Returns:
    - tuple:
        - covariance_df (pandas.DataFrame): The covariance matrix of the combined DataFrame.
        - pair_plot (sns.axisgrid.PairGrid): Pair plot of the combined DataFrame.

    Raises:
    - ValueError: If the list is empty or any DataFrame is empty.
    - TypeError: If any DataFrame contains non-numeric data types.

    Requirements:
    - numpy
    - seaborn
    - pandas

    Examples:
    >>> df1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    >>> df2 = pd.DataFrame({'A': [7, 8, 9], 'B': [10, 11, 12]})
    >>> covariance_df, ax = combined_task([df1, df2])
    >>> type(ax)
    <class 'seaborn.axisgrid.PairGrid'>
    """
    if not df_list:
        raise ValueError("The DataFrame list is empty.")

    # Validate each DataFrame before combining
    for df in df_list:
        if df is None or df.empty:
            raise ValueError("The DataFrame is empty.")

        numeric_df = df.select_dtypes(include=[np.number])
        if numeric_df.shape[1] != df.shape[1]:
            raise TypeError("The DataFrame contains non-numeric data types.")

    # Combine all DataFrames into one
    combined = pd.concat(df_list, ignore_index=True)

    # Compute the combined covariance matrix and pair plot
    covariance_df = combined.cov()
    pair_plot = sns.pairplot(combined)

    return covariance_df, pair_plot
