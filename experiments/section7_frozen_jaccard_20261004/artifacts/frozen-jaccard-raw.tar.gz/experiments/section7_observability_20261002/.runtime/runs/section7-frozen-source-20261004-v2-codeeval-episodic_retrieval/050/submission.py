from collections import Counter
import random
import itertools


def new_task_func(lengths, counts, seed=0):
    """
    Generate random strings from the fixed set of letters ('a', 'b', 'c', 'd', 'e'),
    compute the total frequency of each letter across all strings, and identify
    the most and least frequent letters.

    Parameters:
    - lengths (list of int): The length of each group of strings to be generated.
      Each element corresponds to the string length for the corresponding element
      in `counts`.
    - counts (list of int): The number of random strings to generate for each
      corresponding length in `lengths`.
    - seed (int, optional): A seed for the random number generator to ensure
      reproducibility. Default is 0.

    Requirements:
    - collections.Counter
    - random
    - itertools

    Returns:
    - tuple: (Counter, most_frequent_letter, least_frequent_letter)
        - Counter: total frequency of each letter across all generated strings.
        - most_frequent_letter (str or None): the letter with the highest total
          frequency (first encountered on ties).
        - least_frequent_letter (str or None): the letter with the lowest total
          frequency (first encountered on ties). None values are returned when
          no letters are generated.

    Example:
    >>> new_task_func([5], [2], seed=1)
    (Counter({'a': 3, 'd': 3, 'c': 2, 'e': 1, 'b': 1}), 'a', 'e')
    >>> new_task_func([0], [100], seed=2)
    (Counter(), None, None)
    """
    letters = 'abcde'
    random.seed(seed)

    # Generate the random strings for each (length, count) pair.
    all_strings = []
    for length, count in zip(lengths, counts):
        strings = [
            ''.join(random.choices(letters, k=length))
            for _ in itertools.repeat(None, count)
        ]
        all_strings.extend(strings)

    # Total frequency of each letter across all strings.
    freq = Counter(''.join(all_strings))

    if freq:
        most_frequent, _ = freq.most_common(1)[0]
        least_frequent, _ = min(freq.items(), key=lambda kv: kv[1])
    else:
        most_frequent = None
        least_frequent = None

    return freq, most_frequent, least_frequent
