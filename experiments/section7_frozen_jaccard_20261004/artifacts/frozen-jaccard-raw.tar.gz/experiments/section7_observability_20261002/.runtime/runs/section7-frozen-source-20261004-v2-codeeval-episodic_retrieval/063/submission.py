import random
import re


def new_task_func(texts, seed=None):
    """
    Scramble the letters in each word of every sentence in a list of texts,
    keeping the first and last letters of each word intact.

    Parameters:
    texts (list of str): A list of texts, each containing multiple sentences.
    seed (int, optional): A seed for the random number generator to ensure
                          reproducible results. Defaults to None (not set).

    Returns:
    list of str: A list of scrambled texts, one for each input text.

    Requirements:
    - random
    - re

    Notes:
    - Words are determined by regex word boundaries.
    - The scrambling only affects words longer than three characters,
      leaving shorter words unchanged.
    """
    if seed is not None:
        random.seed(seed)

    def scramble(match):
        word = match.group()
        if len(word) <= 3:
            return word
        middle = list(word[1:-1])
        random.shuffle(middle)
        return word[0] + ''.join(middle) + word[-1]

    return [re.sub(r'\w+', scramble, text) for text in texts]
