import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm


def plot_histograms(arrays: list) -> plt.Figure:
    """
    Plot a histogram of the normalized data from each 2D numpy array in the given
    list, alongside the probability density function (PDF) of a standard normal
    distribution. Each histogram is plotted in a separate subplot within a single
    figure.

    Note:
    - For each input array:
      - The sum of elements in each row is calculated.
      - These row sums are normalized to have a mean of 0 and a standard
        deviation of 1 (subtracting the mean and dividing by the standard
        deviation). If the standard deviation is 0 (all row sums equal), the
        normalized data is an array of zeros.
      - A density-based histogram of the normalized data is plotted with
        semi-transparent (60% opacity) green bars.
      - The PDF of a standard normal distribution is overlaid in red with a
        line width of 2, covering 99% of the standard normal distribution.
      - The subplot title indicates the index of the array it represents.
    - The overall figure has the title
      'Histograms of Normalized Data with Standard Normal PDFs'.

    Parameters:
    - arrays: A list of 2D numpy arrays containing numerical data.

    Returns:
    - fig (matplotlib.figure.Figure): The figure containing one subplot per
      input array.

    Requirements:
    - numpy
    - scipy.stats.norm
    - matplotlib.pyplot

    Example:
    >>> fig = plot_histograms([np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])])
    >>> type(fig)
    <class 'matplotlib.figure.Figure'>
    """
    n = len(arrays)

    # One subplot per array, stacked vertically in a single figure
    fig, axes = plt.subplots(n, 1)
    if n == 1:
        axes = [axes]

    # Range of the PDF curve covering 99% of a standard normal distribution
    x = np.linspace(norm.ppf(0.005), norm.ppf(0.995), 100)

    for i, (ax, arr) in enumerate(zip(axes, arrays)):
        # Sum of elements in each row
        row_sums = np.sum(arr, axis=1)

        # Normalize row sums to mean 0 and standard deviation 1
        mean = np.mean(row_sums)
        std = np.std(row_sums)
        if std == 0:
            normalized_data = np.zeros_like(row_sums, dtype=float)
        else:
            normalized_data = (row_sums - mean) / std

        # Density-based histogram with semi-transparent green bars
        ax.hist(normalized_data, bins=30, density=True, alpha=0.6, color='green')

        # Overlay the standard normal PDF in red with line width 2
        ax.plot(x, norm.pdf(x), 'r-', lw=2)

        # Subplot title indicating the index of the array
        ax.set_title(f"Array {i}")

    # Overall figure title
    fig.suptitle('Histograms of Normalized Data with Standard Normal PDFs')
    fig.tight_layout()

    return fig
