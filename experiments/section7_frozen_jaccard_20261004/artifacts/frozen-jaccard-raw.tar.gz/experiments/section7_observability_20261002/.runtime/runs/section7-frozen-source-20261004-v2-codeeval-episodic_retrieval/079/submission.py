from itertools import zip_longest
from scipy.spatial import distance


def total_travel_distance(points):
    """
    Calculate the total travel distance for a path that starts at the first
    point, visits each consecutive point, and returns to the starting point.

    This function takes a list of tuples, where each tuple contains two numbers
    representing a point in 2D space. It computes the Euclidean distance between
    each consecutive pair of points and adds the distance from the last point
    back to the first point (a round trip).

    If the list is empty or contains only one point, the function returns 0.0.
    If a tuple contains just one number, it is assumed that both coordinates
    are equal to this number.
    Example: (2) == (2, 2)

    Parameters:
    points (list of tuples): A list of tuples where each tuple contains two
                             numbers (x, y), representing a point in 2D space.

    Returns:
    float: The total travel distance of the round-trip path.

    Requirements:
    - itertools
    - scipy.spatial

    Example:
    >>> total_travel_distance([(0, 0), (3, 4)])
    10.0

    >>> total_travel_distance([(0, 0), (1, 1), (1, 0)])
    3.414213562373095

    >>> total_travel_distance([(1, 2)])
    0.0

    >>> total_travel_distance([])
    0.0
    """
    if points is None or len(points) < 2:
        return 0.0

    # Normalize each point to a 2D coordinate pair.
    # A bare number (e.g. 4) or a one-element tuple (e.g. (2,)) means
    # both coordinates are equal to that number.
    pts = []
    for p in points:
        if isinstance(p, (int, float)):
            pts.append((p, p))
        else:
            p = tuple(p)
            if len(p) == 1:
                pts.append((p[0], p[0]))
            else:
                pts.append(tuple(p[:2]))

    # Sum distances between consecutive points, then close the loop
    # by adding the distance from the last point back to the first.
    total = sum(distance.euclidean(a, b) for a, b in zip(pts, pts[1:]))
    total += distance.euclidean(pts[-1], pts[0])
    return float(total)
