import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt


def aggregate_predictions(datasets):
    """
    Performs linear regression on each dataset (using 'date' converted to ordinal
    as the predictor for 'value'), aggregates the predictions from all datasets
    into a single DataFrame, and plots the aggregated predictions against the
    original dates from all datasets.

    Parameters:
        datasets (list): A list of pandas DataFrames, each containing 'date'
            (in datetime format) and 'value' columns.

    Returns:
        tuple:
            - pandas.DataFrame: Aggregated DataFrame containing the original
              'date' and 'value' columns along with the 'prediction' column
              from each dataset's linear regression model.
            - matplotlib.axes._axes.Axes: Plot showing the original values and
              the aggregated predictions across all datasets.
            - list: List of LinearRegression models, one per dataset.

    Raises:
        ValueError: If 'datasets' is not a non-empty list of DataFrames, if any
            dataset is not a valid DataFrame, lacks the required columns, or if
            the 'date' column is not in datetime format.
    """
    if not isinstance(datasets, (list, tuple)) or len(datasets) == 0:
        raise ValueError("'datasets' must be a non-empty list of DataFrames.")

    models = []
    aggregated_parts = []

    for i, df in enumerate(datasets):
        if not isinstance(df, pd.DataFrame):
            raise ValueError(f"Dataset {i} is not a valid pandas DataFrame.")

        if not {"date", "value"}.issubset(df.columns):
            raise ValueError(
                f"Dataset {i} must contain 'date' and 'value' columns."
            )

        if not pd.api.types.is_datetime64_any_dtype(df["date"]):
            raise ValueError(
                f"Dataset {i}: 'date' column must be in datetime format."
            )

        # Convert dates to ordinal values for regression
        X = df["date"].map(pd.Timestamp.toordinal).values.reshape(-1, 1)
        y = df["value"].values

        model = LinearRegression()
        model.fit(X, y)
        predictions = model.predict(X)
        models.append(model)

        aggregated_parts.append(
            pd.DataFrame(
                {
                    "date": df["date"].values,
                    "value": y,
                    "prediction": predictions,
                }
            )
        )

    # Aggregate the predictions from all datasets into a single DataFrame
    aggregated = pd.concat(aggregated_parts, ignore_index=True)

    # Plot the aggregated predictions against the original dates
    fig, ax = plt.subplots()
    ax.scatter(
        aggregated["date"], aggregated["value"], color="blue", label="Original values"
    )
    ax.plot(
        aggregated["date"],
        aggregated["prediction"],
        color="red",
        label="Aggregated predictions",
    )
    ax.set_title("Aggregated Linear Regression Predictions vs Date")
    ax.set_xlabel("Date")
    ax.set_ylabel("Value")
    ax.legend()

    return aggregated, ax, models
