import random
import re


def _generate_sentences(target_words, n_sentences, vocabulary):
    """Core logic: generate n_sentences sentences of 10 sampled words, underscore target words."""
    if not isinstance(n_sentences, int) or isinstance(n_sentences, bool):
        raise ValueError("n_sentences must be a positive integer.")
    if n_sentences < 0:
        raise ValueError("n_sentences must not be negative.")
    if not vocabulary:
        raise ValueError("vocabulary must not be empty.")

    sentences = []
    for _ in range(n_sentences):
        words = random.choices(vocabulary, k=10)
        sentence = ' '.join(words)
        for target in (target_words or []):
            pattern = re.compile(re.escape(target), re.IGNORECASE)
            sentence = pattern.sub(target.replace(' ', '_'), sentence)
        sentences.append(sentence.lower())
    return sentences


def generate_report(data):
    """
    Process multiple sets of (target_words, n_sentences, vocabulary) and build a
    comprehensive report of all processed sentences.

    For each set:
    - n_sentences sentences are generated, each consisting of 10 randomly sampled
      words (with replacement) from the vocabulary, joined by single spaces.
    - If any of the target_words appear in a sentence, the spaces within those
      words/phrases are replaced with underscores (case-insensitive matching).
    - Sentences are returned in all lowercase.
    - Exceptions for negative n_sentences or empty vocabulary are handled: the
      error message is recorded in the report instead of raising.

    Parameters:
    - data (list of tuples): Each tuple is (target_words, n_sentences, vocabulary),
      where target_words is a list of str, n_sentences is a positive int, and
      vocabulary is a non-empty list of str.

    Returns:
    - dict: keys are identifiers for each input set ("set_1", "set_2", ...);
      values are the corresponding lists of processed sentences, or an error
      message string if that set was invalid.
    """
    report = {}
    for idx, item in enumerate(data, start=1):
        key = f"set_{idx}"
        try:
            target_words, n_sentences, vocabulary = item
            report[key] = _generate_sentences(target_words, n_sentences, vocabulary)
        except (ValueError, TypeError) as exc:
            report[key] = str(exc)
    return report
