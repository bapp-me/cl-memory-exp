import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.signal import get_window

def generate_complex_wave_with_harmonics(amplitudes, frequencies, time):
    """
    Generates a complex wave composed of multiple harmonics, each with its own
    amplitude and frequency, over the given time points. A Hann window is applied
    to each harmonic to reduce edge effects. The combined complex wave is returned
    along with a plot showing both the real and imaginary parts.

    Parameters:
        amplitudes (list of float): Amplitudes of the harmonics.
        frequencies (list of float): Frequencies of the harmonics.
        time (numpy.ndarray): The time points over which to generate the wave.

    Returns:
        numpy.ndarray: The combined complex wave as a numpy array of complex numbers.
        matplotlib.figure.Figure: The figure object of the plot.
        matplotlib.axes.Axes: The axes object of the plot.

    Notes:
        - The plot title is 'Complex Wave with Multiple Harmonics and Hann Window'.
        - The x-label of the plot is 'Time'.
        - The y-label of the plot is 'Amplitude'.
        - The plot displays both the real and imaginary parts of the combined wave.
    """
    time = np.asarray(time, dtype=float)
    n = len(time)

    # Hann window to reduce edge effects, applied to each harmonic.
    window = get_window('hann', n)

    # Sum the harmonics: real part = cosine component, imaginary part = sine component.
    wave = np.zeros(n, dtype=complex)
    for amplitude, frequency in zip(amplitudes, frequencies):
        wave += amplitude * window * np.exp(2j * np.pi * frequency * time)

    # Plot the real and imaginary parts of the combined wave.
    fig, ax = plt.subplots()
    ax.plot(time, wave.real, label='Real')
    ax.plot(time, wave.imag, label='Imaginary')
    ax.set_title('Complex Wave with Multiple Harmonics and Hann Window')
    ax.set_xlabel('Time')
    ax.set_ylabel('Amplitude')
    ax.legend()

    return wave, fig, ax
