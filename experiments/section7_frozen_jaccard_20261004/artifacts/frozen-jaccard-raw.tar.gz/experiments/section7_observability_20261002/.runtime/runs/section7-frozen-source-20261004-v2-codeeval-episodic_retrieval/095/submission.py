import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']


def generate_report(datasets):
    """
    Generate a detailed category distribution report for multiple datasets.

    Each dataset is represented by a tuple containing its name and the range
    (min, max) for the counts of categories. Random counts are generated for
    each category within the specified range for every dataset.

    Parameters:
    - datasets (list): A list of tuples, where each tuple contains:
        * name (str): The name of the dataset.
        * value_range (tuple): A tuple specifying the range (min, max)
          for generating random counts of categories.

    Returns:
    - DataFrame: A pandas DataFrame combining the category distributions
      for all datasets, with three columns: 'Dataset' (the dataset name),
      'Category' (category names) and 'Count' (count of each category).

    Requirements:
    - pandas
    - random

    Example:
    >>> import random
    >>> random.seed(0)
    >>> df = generate_report([('ds1', (0, 10)), ('ds2', (10, 20))])
    >>> df.columns.tolist()
    ['Dataset', 'Category', 'Count']
    >>> set(df['Dataset'])
    {'ds1', 'ds2'}
    >>> df.groupby('Dataset').size().tolist()
    [5, 5]
    """
    frames = []
    for name, value_range in datasets:
        min_val, max_val = value_range

        counts = []
        for _ in CATEGORIES:
            if isinstance(min_val, int) and isinstance(max_val, int):
                counts.append(random.randint(min_val, max_val))
            else:
                counts.append(random.uniform(min_val, max_val))

        frames.append(pd.DataFrame({'Dataset': name,
                                    'Category': CATEGORIES,
                                    'Count': counts}))

    report = pd.concat(frames, ignore_index=True)
    return report
