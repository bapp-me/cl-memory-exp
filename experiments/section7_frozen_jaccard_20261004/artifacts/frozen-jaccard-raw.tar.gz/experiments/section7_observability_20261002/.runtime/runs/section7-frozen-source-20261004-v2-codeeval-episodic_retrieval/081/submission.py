from datetime import datetime
import numpy as np
from dateutil.parser import parse

LEAP_SECONDS = np.array(
    [
        1972,
        1973,
        1974,
        1975,
        1976,
        1977,
        1978,
        1979,
        1980,
        1981,
        1982,
        1983,
        1985,
        1988,
        1990,
        1993,
        1994,
        1997,
        1999,
        2006,
        2009,
        2012,
        2015,
        2016,
        2020,
    ]
)


def total_elapsed_seconds(date_list):
    """
    Calculate the total number of seconds elapsed from each date in a list of
    date strings until the current time, including any leap seconds that
    occurred in each period, and return the sum of all these elapsed seconds.

    Parameters:
    date_list (list of str): Date strings in "yyyy-mm-dd hh:mm:ss" format.

    Returns:
    int: The sum of all elapsed seconds (including leap seconds) across all dates.
    """
    now = datetime.now()
    total = 0

    for date_str in date_list:
        parsed = parse(date_str)

        # Raw elapsed seconds according to (uniform) datetime arithmetic
        elapsed = (now - parsed).total_seconds()

        # Count leap seconds that occurred after the given date (up to now):
        # one for every leap-second year strictly greater than the start year
        # and not later than the current year.
        leap_count = int(
            np.sum((LEAP_SECONDS > parsed.year) & (LEAP_SECONDS <= now.year))
        )

        total += int(elapsed) + leap_count

    return int(total)
