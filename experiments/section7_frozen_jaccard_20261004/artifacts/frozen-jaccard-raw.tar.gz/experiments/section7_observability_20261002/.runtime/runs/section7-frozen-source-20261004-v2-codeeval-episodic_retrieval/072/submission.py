from collections import defaultdict
import re


def new_task_func(words: list) -> dict:
    """
    Find the occurrences of each two-letter combination across all words in the
    given list, where only alphabetic characters are considered.

    The function outputs a dictionary with keys as two-letter combinations and
    values as their counts across all words.

    Requirements:
    - collections.defaultdict
    - re

    Parameters:
    words (list): A list of input strings.

    Returns:
    collections.defaultdict: A dictionary with keys as two-letter combinations
    and values as their counts across all words.

    Example:
    >>> new_task_func(['abcdef', 'aabbcc'])
    defaultdict(<class 'int'>, {'ab': 2, 'bc': 2, 'cd': 1, 'de': 1, 'ef': 1, 'aa': 1, 'bb': 1, 'cc': 1})
    >>> new_task_func(['a1!b@c#d$'])
    defaultdict(<class 'int'>, {'ab': 1, 'bc': 1, 'cd': 1})
    """
    counts = defaultdict(int)

    for word in words:
        # Keep only alphabetic characters
        sanitized = ''.join(re.findall(r'[A-Za-z]', word))

        # Count consecutive two-letter combinations
        for i in range(len(sanitized) - 1):
            counts[sanitized[i:i + 2]] += 1

    return counts
