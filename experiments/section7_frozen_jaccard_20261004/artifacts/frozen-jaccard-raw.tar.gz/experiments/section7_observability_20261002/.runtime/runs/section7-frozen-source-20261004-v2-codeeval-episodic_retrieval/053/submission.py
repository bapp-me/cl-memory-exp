import matplotlib.pyplot as plt
import numpy as np


def generate_grid_of_plots(rows, cols, n):
    """
    Generates a grid of scatter plots, where each scatter plot represents a
    different set of random points.

    The grid has 'rows' rows and 'cols' columns. Each scatter plot contains
    'n' points, generated with different seeds to ensure variability.

    Parameters:
    - rows (int): Number of rows in the grid.
    - cols (int): Number of columns in the grid.
    - n (int): Number of random points per scatter plot.

    Returns:
    - figures (list of matplotlib.figure.Figure): A list of figures, each
      representing a scatter plot in the grid (row by row, left to right).
    - points (list of lists): A list of lists of the same grid shape
      (rows x cols), where each inner list contains the (x, y) tuples of
      the points for the corresponding scatter plot.

    Requirements:
    - numpy
    - matplotlib.pyplot
    """
    figures = []
    points = []
    seed = 0

    for r in range(rows):
        row_points = []
        for c in range(cols):
            # Different seed for each scatter plot to ensure variability
            np.random.seed(seed)
            x = np.random.rand(n)
            y = np.random.rand(n)

            fig, ax = plt.subplots()
            ax.scatter(x, y)
            ax.set_title(f"Scatter plot ({r + 1},{c + 1})")
            ax.set_xlabel("X")
            ax.set_ylabel("Y")

            figures.append(fig)
            row_points.append(list(zip(x.tolist(), y.tolist())))

            seed += 1
        points.append(row_points)

    return figures, points
