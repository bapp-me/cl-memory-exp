import pandas as pd
from datetime import datetime
import holidays


def total_business_days(date_ranges, country='US'):
    """Calculate the total number of business days across multiple date ranges.

    Business days are weekdays (Monday-Friday) that are not public holidays
    of the specified country. Each date range includes both its start and end
    dates when counting.

    Parameters:
        date_ranges (list[tuple[datetime, datetime]]): A list of (start, end)
            date range tuples. Both endpoints are inclusive.
        country (str): ISO country code used to determine public holidays.
            Default is 'US'.

    Returns:
        int: The total count of business days across all provided date ranges.

    Requirements:
        - pandas
        - datetime
        - holidays

    Example:
        >>> total_business_days([(datetime(2023, 1, 1), datetime(2023, 1, 10))])
        6
    """
    if not date_ranges:
        return 0

    # Collect all years spanned by the ranges so holidays can be fetched once
    years = set()
    for start, end in date_ranges:
        years.update(range(start.year, end.year + 1))
    country_holidays = holidays.country_holidays(country, years=sorted(years))
    holiday_list = list(country_holidays)

    total = 0
    for start, end in date_ranges:
        bdays = pd.bdate_range(start=start, end=end, freq='C',
                               holidays=holiday_list)
        total += len(bdays)

    return total
