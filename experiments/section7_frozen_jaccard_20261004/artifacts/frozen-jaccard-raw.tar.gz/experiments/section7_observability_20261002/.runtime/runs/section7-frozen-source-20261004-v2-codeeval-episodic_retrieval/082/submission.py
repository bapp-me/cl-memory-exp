from collections import Counter
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def process_menus(list_of_menus):
    """
    Given a list of restaurant menus, where each menu is represented as a nested list
    of menu items, flatten the items across all menus and visualize the frequency of
    each menu item using a seaborn barplot.

    Parameters:
        list_of_menus (list): A list of restaurant menus, where each menu is a nested
        list of menu items.

    Returns:
        matplotlib.axes.Axes: An Axes object representing the combined visualization,
        or None if there are no items to plot.

    Requirements:
        - collections
        - seaborn
        - pandas
        - matplotlib

    Example:
        >>> ax = process_menus([['Pizza', 'Burger'], ['Pizza', 'Coke'], ['Pasta', 'Coke']])
        >>> isinstance(ax, matplotlib.axes.Axes)
        True
    """
    if not list_of_menus:
        return None

    # Flatten the nested list of menu items across all menus
    flattened = [item for menu in list_of_menus for item in menu]

    if not flattened:
        return None

    # Count the frequency of each menu item
    item_counts = Counter(flattened)

    # Create a DataFrame for plotting
    df = pd.DataFrame(item_counts.items(), columns=['Menu Item', 'Frequency'])

    # Create the seaborn barplot
    plt.figure(figsize=(10, 6))
    ax = sns.barplot(x='Menu Item', y='Frequency', data=df)

    ax.set_xlabel('Menu Item')
    ax.set_ylabel('Frequency')
    ax.set_title('Frequency of Menu Items Across All Menus')

    return ax
