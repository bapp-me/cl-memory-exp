import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt


def combined_visualization(series_pairs, n_clusters=3):
    """
    Perform K-Means clustering on each pair of pandas Series and visualize all
    clusters on a single plot. Each cluster from different pairs is
    distinguishable by color and marker type.

    Parameters:
    - series_pairs (list): A list of tuples, where each tuple contains two
      pandas Series (s1, s2) representing the x and y coordinates of the data
      points for that pair.
    - n_clusters (int, optional): The number of clusters to form for each pair.
      Defaults to 3.

    Returns:
    - matplotlib.axes.Axes: The Axes object of the combined plot showing all
      data points colored and marked according to their pair and cluster
      label, with a legend indicating which cluster corresponds to which pair
      of Series. Returns None if series_pairs is empty.

    Raises:
    - ValueError: If a pair does not consist of two pandas Series of equal length.
    """
    if not series_pairs:
        return None

    fig, ax = plt.subplots()

    colors = plt.cm.tab10.colors
    markers = ['o', 's', '^', 'D', 'v', 'P', 'X', '*', '<', '>']

    for i, pair in enumerate(series_pairs):
        s1, s2 = pair
        if not isinstance(s1, pd.Series) or not isinstance(s2, pd.Series):
            raise ValueError("Each pair must contain two pandas Series")
        if len(s1) != len(s2):
            raise ValueError("The two Series in each pair must have the same length")

        data = np.column_stack((s1.values, s2.values))

        kmeans = KMeans(n_clusters=n_clusters, random_state=0, n_init=10)
        labels = kmeans.fit_predict(data)

        color = colors[i % len(colors)]
        marker = markers[i % len(markers)]

        for c in range(n_clusters):
            mask = labels == c
            ax.scatter(data[mask, 0], data[mask, 1],
                       color=color,
                       marker=marker,
                       label=f'Pair {i + 1} - Cluster {c}')

    ax.set_title('K-Means Clustering')
    ax.set_xlabel('s1')
    ax.set_ylabel('s2')
    ax.legend(title='Clusters')

    return ax
