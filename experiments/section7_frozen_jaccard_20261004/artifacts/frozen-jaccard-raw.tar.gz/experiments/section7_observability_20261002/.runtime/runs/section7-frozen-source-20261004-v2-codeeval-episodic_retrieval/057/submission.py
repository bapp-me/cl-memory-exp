import base64
import pandas as pd


def process_datasets(datasets):
    """
    Processes a list of datasets (dicts of lists), encoding each dataset as a Base64 string.

    Each dataset is first converted to a Pandas DataFrame, then serialized to CSV format,
    encoded to bytes, and finally encoded to a Base64 string.

    Parameters:
        datasets (list of dict): A list of dictionaries, where each dictionary maps
            column names (keys) to lists of values.

    Returns:
        list of str: A list of Base64 encoded strings corresponding to each dataset's
            CSV representation, in the same order as the input datasets.

    Requirements:
        - base64
        - pandas

    Example:
        >>> datasets = [{'A': [1, 2, 3], 'B': [4, 5, 6]}]
        >>> encoded = process_datasets(datasets)
        >>> isinstance(encoded, list) and len(encoded) == 1
        True
        >>> isinstance(encoded[0], str) and len(encoded[0]) > 0
        True
    """
    encoded_datasets = []
    for dataset in datasets:
        # Convert the dict of lists into a Pandas DataFrame
        df = pd.DataFrame(dataset)

        # Convert the DataFrame to CSV format (without the index) and encode to bytes
        csv_bytes = df.to_csv(index=False).encode('utf-8')

        # Encode the bytes to a Base64 string
        encoded_datasets.append(base64.b64encode(csv_bytes).decode('utf-8'))

    return encoded_datasets
