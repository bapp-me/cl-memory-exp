from itertools import cycle
from random import choice, seed


def generate_grid(rows, cols, colors=['Red', 'Green', 'Blue', 'Yellow', 'Purple'], rng_seed=None):
    """
    Generates a grid (list of lists) of colors with 'rows' rows and 'cols' columns.
    Each cell in the grid follows a pattern that alternates between a cyclic
    sequence of colors as defined in the parameter 'colors', and random colors
    from the same list. The alternation continues across the whole grid in
    row-major (reading) order, so that flattening the grid reproduces the
    single-sequence color pattern.

    Optionally, a seed for the random number generator can be provided for
    repeatable randomness.

    If rows or cols is smaller than or equal to zero, an empty list is returned.

    Parameters:
    rows (int): The number of rows in the grid.
    cols (int): The number of columns in the grid.
    colors (list of str, optional): The list of colors to generate from.
                Defaults to ['Red', 'Green', 'Blue', 'Yellow', 'Purple'].
    rng_seed (int, optional): A seed for the random number generator to ensure
                              repeatability of the random color selection.
                              If 'None', the randomness is based on system time
                              or other sources of entropy.

    Returns:
    list of lists: A list of 'rows' sublists, each containing 'cols' color strings.
                   Cell (i, j) corresponds to index i*cols + j of the flattened
                   alternating pattern: even indices take the next cyclic color,
                   odd indices take a random color from the list.

    Requirements:
    - itertools
    - random

    Examples:
    >>> grid = generate_grid(2, 2, rng_seed=123)
    >>> print(grid)
    [['Red', 'Red'], ['Green', 'Blue']]

    >>> colors = ['Brown', 'Green', 'Black']
    >>> grid = generate_grid(2, 3, colors=colors, rng_seed=42)
    >>> print(grid)
    [['Brown', 'Black', 'Green'], ['Brown', 'Black', 'Brown']]
    """
    if rows <= 0 or cols <= 0:
        return []

    if rng_seed is not None:
        seed(rng_seed)

    cyclic_colors = cycle(colors)
    grid = []
    index = 0
    for _ in range(rows):
        row = []
        for _ in range(cols):
            if index % 2 == 0:
                row.append(next(cyclic_colors))
            else:
                row.append(choice(colors))
            index += 1
        grid.append(row)
    return grid
