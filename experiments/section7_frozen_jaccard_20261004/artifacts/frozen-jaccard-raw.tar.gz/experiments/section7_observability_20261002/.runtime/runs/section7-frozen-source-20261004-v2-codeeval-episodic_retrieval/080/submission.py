import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd


def process_dataframes(dataframes):
    """
    Processes a list of dataframes by replacing NaN values in each numeric column
    with the mean of that column, calculating the statistics for each numeric
    column, and generating a distribution chart for each numeric column.

    Parameters:
        dataframes (list): A list of pandas DataFrames containing numeric
                           columns with potential NaN values.

    Returns:
        list: A list of tuples, where each tuple contains:
            - DataFrame: The processed dataframe with NaN values replaced by
              the column averages.
            - List[matplotlib.axes.Axes]: A list of distribution plots (one per
              numeric column in the corresponding dataframe).
    """
    results = []

    for df in dataframes:
        # Work on a copy so the original DataFrame is not modified.
        df = df.copy()

        # Identify numeric columns only.
        numeric_cols = df.select_dtypes(include=np.number).columns

        plots = []
        if len(numeric_cols) > 0:
            # Replace NaN values with the average of the respective column.
            df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())

            # Calculate statistics for each numeric column.
            stats = df[numeric_cols].describe()

            # Generate a distribution chart for each numeric column.
            fig, axs = plt.subplots(
                1,
                len(numeric_cols),
                figsize=(6 * len(numeric_cols), 4),
                squeeze=False,
            )
            for ax, col in zip(axs[0], numeric_cols):
                sns.histplot(df[col], bins=10, ax=ax, kde=True)
                ax.set_title(col)
                plots.append(ax)

        results.append((df, plots))

    return results
