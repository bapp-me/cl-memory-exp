import pandas as pd
import numpy as np


def calculate_stats_for_students(test_results):
    """
    Calculate the average test score and the standard deviation for each student
    from a list of dictionaries containing test results.

    Parameters:
        test_results (list): A list of dictionaries, each containing test results.
            Each dictionary is expected to have a 'Student' key (the student ID)
            and a 'Score' key (the test score for that entry).

    Returns:
        dict: A dictionary where the keys are student IDs and the values are
              tuples containing (average_score, standard_deviation) for that student.

    Raises:
        ValueError: If a student does not have any (valid) test scores, or if the
                    input is malformed.

    Requirements:
        - pandas
        - numpy

    Example:
        >>> calculate_stats_for_students([{'Student': 1, 'Score': 10},
        ...                               {'Student': 2, 'Score': 1},
        ...                               {'Student': 1, 'Score': 1},
        ...                               {'Student': 1, 'Score': 1}])
        {1: (4.0, 5.196152422706632), 2: (1.0, 0.0)}
    """
    if not test_results:
        raise ValueError("No test results provided.")

    rows = []
    for entry in test_results:
        if not isinstance(entry, dict):
            raise ValueError("Each test result must be a dictionary.")
        # Locate student and score keys (case-insensitive lookup)
        student_key = next((k for k in entry if str(k).lower() == 'student'), None)
        score_key = next((k for k in entry if str(k).lower() == 'score'), None)
        if student_key is None or score_key is None:
            raise ValueError("Each test result must contain 'Student' and 'Score' keys.")
        rows.append({student_key: entry[student_key], score_key: entry[score_key]})

    df = pd.DataFrame(rows)
    student_col = df.columns[0]
    score_col = df.columns[1]

    stats = {}
    for student, group in df.groupby(student_col):
        scores = pd.to_numeric(group[score_col], errors='coerce').dropna()
        if scores.empty:
            raise ValueError(f"Student {student} does not have any test scores.")
        avg = scores.mean()
        std = scores.std(ddof=1) if len(scores) > 1 else 0.0
        stats[student] = (float(avg), float(std))
    return stats
