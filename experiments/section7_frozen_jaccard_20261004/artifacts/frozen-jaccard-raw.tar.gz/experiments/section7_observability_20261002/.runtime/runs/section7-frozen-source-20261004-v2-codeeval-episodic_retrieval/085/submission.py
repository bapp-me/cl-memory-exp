import pandas as pd
from sklearn.cluster import KMeans
import numpy as np


def overall_clustering(data_sets, n_clusters=2, random_state=0):
    """
    Perform K-Means clustering on each set of (x, y) coordinates separately and
    then determine the overall centroids and labels by averaging the results.

    Parameters:
    - data_sets: A collection of coordinate sets. Each set may be:
        * a pandas DataFrame with 'x' and 'y' columns (or exactly two columns),
        * a tuple/list of two sequences (x_values, y_values),
        * a 2D numpy array of shape (n_points, 2).
    - n_clusters (int, optional): Number of clusters to form for each set. Defaults to 2.
    - random_state (int, optional): Random state for K-Means reproducibility. Defaults to 0.

    Returns:
    tuple:
        - overall_labels (numpy.ndarray): The element-wise average of the cluster
          labels obtained from each data set (rounded to the nearest integer).
        - overall_centroids (numpy.ndarray): The average of the cluster centroids
          obtained from each data set, of shape (n_clusters, 2).

    Requirements:
    - pandas
    - scikit-learn
    - numpy
    """
    centroids_list = []
    labels_list = []

    for data in data_sets:
        # Convert each data set into a 2D numpy array of shape (n_points, 2)
        if isinstance(data, pd.DataFrame):
            if 'x' in data.columns and 'y' in data.columns:
                arr = data[['x', 'y']].values
            else:
                arr = data.values
        elif isinstance(data, (tuple, list)) and len(data) == 2 and np.ndim(data[0]) <= 1:
            arr = np.column_stack((np.asarray(data[0]), np.asarray(data[1])))
        else:
            arr = np.asarray(data)

        kmeans = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
        kmeans.fit(arr)

        labels_list.append(kmeans.labels_)
        centroids_list.append(kmeans.cluster_centers_)

    # Average the centroids across all data sets
    overall_centroids = np.mean(np.array(centroids_list), axis=0)

    # Average the labels across all data sets (rounded to the nearest cluster index)
    overall_labels = np.round(np.mean(np.array(labels_list), axis=0)).astype(int)

    return overall_labels, overall_centroids
