from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def combined_heatmap(list_of_dfs):
    """
    Standardize the numeric columns of each DataFrame in a list and return a
    combined heatmap of the correlation matrices for all DataFrames.

    For each DataFrame:
      - Only numeric columns are considered.
      - Missing values are replaced by the column's average.
      - Columns are standardized (zero mean, unit variance) using StandardScaler.
      - The correlation matrix of the standardized data is computed.

    The correlation matrices of all DataFrames are then combined by taking the
    element-wise mean (aligned on the union of column names) and plotted as a
    single seaborn heatmap.

    Parameters:
    - list_of_dfs (list of pandas.DataFrame): The list of DataFrames to process.

    Returns:
    - matplotlib.axes.Axes: The combined heatmap of the correlation matrices.
    """
    # Compute the standardized correlation matrix for each DataFrame
    corr_matrices = []
    for df in list_of_dfs:
        # Keep only numeric columns
        numeric_df = df.select_dtypes(include=[np.number]).copy()
        if numeric_df.empty:
            continue
        # Replace missing values with the column's average
        numeric_df = numeric_df.fillna(numeric_df.mean())
        # Standardize the numeric columns
        scaler = StandardScaler()
        standardized = pd.DataFrame(
            scaler.fit_transform(numeric_df),
            columns=numeric_df.columns,
            index=numeric_df.index,
        )
        corr_matrices.append(standardized.corr())

    if not corr_matrices:
        fig, ax = plt.subplots()
        return ax

    # Combine correlation matrices: element-wise mean over all DataFrames,
    # aligned on the union of column names.
    stacked = pd.concat([corr.stack() for corr in corr_matrices])
    combined_corr = stacked.groupby(level=[0, 1]).mean().unstack()

    # Plot the combined heatmap
    ax = sns.heatmap(combined_corr, annot=True, cmap="coolwarm")

    return ax
