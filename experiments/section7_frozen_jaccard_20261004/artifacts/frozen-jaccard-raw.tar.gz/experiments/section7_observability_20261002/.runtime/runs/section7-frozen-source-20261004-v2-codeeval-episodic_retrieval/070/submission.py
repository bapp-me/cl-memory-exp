import numpy as np
from scipy.stats import norm


def new_solution(dataset: list, threshold: float = 2.0) -> dict:
    """
    Identify outliers in each group of a dataset based on the Z score.

    For each 1D numpy array (group) in the dataset, a normal distribution is
    fitted to the data. The mean and standard deviation from the fit are used
    to compute the z scores of each data point. If the absolute z score of a
    data point is larger than the threshold, it is considered an outlier and
    its index is recorded.

    If the standard deviation of a group is 0, an empty list is returned as
    the outliers for that group.

    Parameters:
    dataset (list): A list of 1D numpy arrays, each representing a group of data.
    threshold (float): The outlier threshold. Defaults to 2.

    Returns:
    dict: A dictionary where the keys are the indices of the groups and the
          values are tuples containing:
          - list: the indices of outliers in the group (empty if std is 0)
          - float: the mean of the fitted normal distribution
          - float: the variance of the fitted normal distribution

    Requirements:
    - numpy
    - scipy.stats.norm

    Example:
    >>> data1 = np.array([1, 2, 3, 4, 5, 6, 100])
    >>> data2 = np.array([3, 3, 3])
    >>> results = new_solution([data1, data2])
    >>> results[0]
    ([6], 17.285714285714285, 1142.7755102040817)
    >>> results[1]
    ([], 3.0, 0.0)
    """
    results = {}
    for i, data in enumerate(dataset):
        data = np.asarray(data)
        mean, std = norm.fit(data)
        if std == 0:
            results[i] = ([], mean, std ** 2)
        else:
            z_scores = (data - mean) / std
            outliers = list(np.where(np.abs(z_scores) > threshold)[0])
            results[i] = (outliers, mean, std ** 2)
    return results
