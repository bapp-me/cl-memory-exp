import pandas as pd
from scipy.spatial import distance
import matplotlib.pyplot as plt


def new_task_func(list_of_pairs):
    """
    Given a list of pairs of lists, compute the Euclidean distance for each pair,
    create a Pandas DataFrame for each pair with indices 'A' and 'B', and then draw
    the values with a line displaying the Euclidean distance for each pair.

    Parameters:
    list_of_pairs (list): A list of pairs of lists of numbers.

    Returns:
    list: The computed Euclidean distances for each pair.
    list: A list of DataFrames, each containing a pair of lists as rows indexed 'A' and 'B'.
    list: A list of the generated plot's Axes objects.

    Requirements:
    - pandas
    - scipy.spatial
    - matplotlib.pyplot

    Example:
    >>> distances, dfs, axes = new_task_func([([1, 2, 3], [2, 3, 4])])
    >>> print(distances)
    [1.7320508075688772]
    """
    distances = []
    dfs = []
    axes = []

    for a, b in list_of_pairs:
        # Compute the Euclidean distance between the two lists
        euclidean_distance = distance.euclidean(a, b)

        # Create a DataFrame from the two lists with indices 'A' and 'B'
        df = pd.DataFrame([a, b], index=["A", "B"])

        # Plot the values of both lists as lines
        ax = df.T.plot(marker="o", legend=True)

        # Draw a dashed line between the last points of 'A' and 'B' to visualize the distance
        ax.plot(
            [len(a) - 1, len(a) - 1],
            [a[-1], b[-1]],
            "k--",
            label=f"Euclidean distance = {euclidean_distance:.2f}",
        )
        ax.legend()

        distances.append(euclidean_distance)
        dfs.append(df)
        axes.append(ax)

    return distances, dfs, axes
