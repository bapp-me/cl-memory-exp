import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA


def new_task_func(data_matrices, n_components=2):
    """
    Apply PCA with n_components components to each 2D data matrix in a list of
    matrices, calculate the mean value of each component for each matrix, and
    then plot the cumulative explained variance of the components across all
    matrices in a single plot.

    - Returns a list of dataframes, one per input matrix. Each dataframe
      contains columns 'Component 1', 'Component 2', ... corresponding to the
      rows of the original matrix mapped in the PCA space, plus a column
      'Mean' holding the average component value per row.
    - The plot has xlabel 'Number of Components' and ylabel
      'Cumulative Explained Variance'. The cumulative explained variance is
      computed from the average explained variance ratio of each component
      across all matrices.

    Parameters:
    data_matrices (list of numpy.array): List of 2D data matrices.
    n_components (int): Number of PCA components, default 2.

    Returns:
    tuple:
        - list of pandas.DataFrame: PCA transformed data with per-row means,
          one DataFrame per input matrix.
        - matplotlib.axes._axes.Axes: Plot of the cumulative explained
          variance across all matrices.
    """
    dfs = []
    all_ratios = []

    for data_matrix in data_matrices:
        # Apply PCA to each matrix
        pca = PCA(n_components=n_components)
        transformed = pca.fit_transform(data_matrix)

        # Build the DataFrame with component columns
        df = pd.DataFrame(
            transformed,
            columns=[f"Component {i + 1}" for i in range(transformed.shape[1])],
        )

        # Add the mean of the component values per row
        df["Mean"] = df.mean(axis=1)
        dfs.append(df)

        all_ratios.append(pca.explained_variance_ratio_)

    # Average explained variance ratio per component across all matrices,
    # then compute the cumulative explained variance
    mean_ratios = np.mean(all_ratios, axis=0)
    cumulative_variance = np.cumsum(mean_ratios)

    # Single plot of cumulative explained variance
    fig, ax = plt.subplots()
    ax.plot(
        range(1, len(cumulative_variance) + 1),
        cumulative_variance,
        marker="o",
    )
    ax.set_xlabel("Number of Components")
    ax.set_ylabel("Cumulative Explained Variance")

    return dfs, ax
