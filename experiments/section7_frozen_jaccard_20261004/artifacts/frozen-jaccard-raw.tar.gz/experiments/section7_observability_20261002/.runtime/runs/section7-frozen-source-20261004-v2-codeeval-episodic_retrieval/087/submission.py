import struct
import random

# Constants
KEYS = ['470FC614', '4A0FC614', '4B9FC614', '4C8FC614', '4D7FC614']


def generate_rounded_floats(hex_keys):
    """
    Given a list of hexadecimal strings, generate a list of rounded float
    numbers by converting each hexadecimal string to a float and rounding
    it to 2 decimal places.

    Each hexadecimal string is interpreted as the big-endian byte
    representation of an IEEE 754 single-precision (32-bit) float.

    Parameters:
    - hex_keys (list): A list of hexadecimal strings.

    Returns:
    - rounded_floats (list): A list of the rounded float numbers.

    Requirements:
    - struct

    Example:
    >>> generate_rounded_floats(['470FC614'])
    [36806.08]
    """
    rounded_floats = []
    for hex_key in hex_keys:
        # Convert the hexadecimal string to bytes and interpret it as a
        # big-endian IEEE 754 single-precision (32-bit) float
        float_value = struct.unpack('>f', bytes.fromhex(hex_key))[0]
        # Round the float number to 2 decimal places
        rounded_floats.append(round(float_value, 2))
    return rounded_floats
