import bisect
import statistics
import numpy as np
import matplotlib.pyplot as plt


def analyze_dataframes(dfs, columns, value):
    """
    Analyze each DataFrame's specified column to find the values larger than the
    average, count the number of values larger than a given value, and generate
    a histogram plot for each DataFrame.

    Parameters:
        dfs (list): A list of pandas DataFrames.
        columns (list): A list of column names, one per DataFrame.
        value (float): The value to compare the column data against.

    Returns:
        list: A list of tuples, where each tuple contains:
              (numpy.ndarray of values greater than the average,
               int count of values greater than the given value,
               matplotlib.axes.Axes object for the histogram plot).

    Raises:
        ValueError: If any column does not exist in the corresponding DataFrame,
                    or if value is not a number.
    """
    # Validate that value is a number (bool is excluded, since bool subclasses int)
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError("value must be a number.")

    results = []
    for df, column in zip(dfs, columns):
        # Validate that the column exists in the DataFrame
        if column not in df.columns:
            raise ValueError(f"Column '{column}' does not exist in the DataFrame.")

        # Extract the data from the column (drop missing values for robust statistics)
        data = df[column].dropna().values

        # Compute the mean of the column using statistics
        avg = statistics.mean(data)

        # Find the values that are larger than the average
        greater_avg = data[data > avg]

        # Count the number of values larger than the given value using bisect
        # on a sorted copy of the data.
        sorted_data = sorted(data)
        idx = bisect.bisect_right(sorted_data, value)
        num_greater_value = len(sorted_data) - idx

        # Generate a histogram plot of the column
        fig, ax = plt.subplots()
        ax.hist(data, bins=10, edgecolor='black')
        ax.set_title(f"Histogram of '{column}'")
        ax.set_xlabel(column)
        ax.set_ylabel("Frequency")

        results.append((greater_avg, num_greater_value, ax))

    return results
