import numpy as np
import matplotlib.pyplot as plt
import random

# Constants
NUMBERS = list(range(1, 7))  # Adjusting for dice rolls (1 to 6)


def combined_task_func(sets, rolls_per_set, seed=None):
    """
    Simulate multiple sets of dice rolls, calculate the frequency of each result
    for each set, and return the combined frequency array and a histogram of the
    combined results.

    Note:
        The dice rolls have 6 possible outcomes.
        The histogram has the title 'Combined Histogram of Dice Rolls',
        with the x-axis labeled 'Dice Value' and the y-axis labeled
        'Combined Frequency'.

    Parameters:
    sets (int): The number of sets of dice rolls.
    rolls_per_set (int): The number of dice rolls per set.
    seed (int, optional): Seed for the random number generator. Defaults to None.

    Returns:
    tuple: A tuple containing:
        - np.array: A numpy array with the combined frequency of each outcome
          (1 through 6).
        - matplotlib.Axes: Axes object representing the histogram.
    """
    if seed is not None:
        random.seed(seed)

    combined_rolls = []
    for _ in range(sets):
        combined_rolls.extend(random.randint(1, 6) for _ in range(rolls_per_set))

    # Combined frequency of each outcome (1 through 6)
    combined_freq = np.array([combined_rolls.count(n) for n in NUMBERS])

    # Create the histogram
    fig, ax = plt.subplots()
    ax.bar(NUMBERS, combined_freq)
    ax.set_xticks(NUMBERS)
    ax.set_title('Combined Histogram of Dice Rolls')
    ax.set_xlabel('Dice Value')
    ax.set_ylabel('Combined Frequency')

    return combined_freq, ax
