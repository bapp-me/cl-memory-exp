import pandas as pd
import numpy as np


def process_datasets(datasets, key_prefix, min_value, max_value):
    """
    Process a list of datasets, adding a uniquely-named column with random
    integer values within a specified range to each one.

    Parameters:
    datasets (list): A list of pandas DataFrames. Each dataset gets a new
        column of random values. If any element is not a pandas DataFrame,
        a TypeError is raised.
    key_prefix (str): The base name for the new column. Each dataset's new
        column is named uniquely, e.g. "{key_prefix}_0", "{key_prefix}_1", ...
        (with an additional suffix appended if such a column already exists
        in that dataset, to avoid conflicts).
    min_value (int): The minimum value (inclusive) for the randomly generated
        integers in the new column.
    max_value (int): The maximum value (inclusive) for the randomly generated
        integers in the new column.

    Returns:
    list: A list of updated pandas DataFrames, each with its new random
        column added. The input DataFrames are not modified in place.

    Raises:
    TypeError: If any dataset in the list is not a pandas DataFrame.

    Requirements:
    - numpy
    - pandas
    """
    if not isinstance(datasets, list):
        raise TypeError("datasets must be a list of pandas DataFrames.")

    updated_datasets = []

    for index, dataset in enumerate(datasets):
        if not isinstance(dataset, pd.DataFrame):
            raise TypeError(
                f"Dataset at index {index} is not a pandas DataFrame."
            )

        # Determine a unique column name for this dataset.
        column_name = f"{key_prefix}_{index}"
        suffix = 1
        while column_name in dataset.columns:
            column_name = f"{key_prefix}_{index}_{suffix}"
            suffix += 1

        # Work on a copy so the original DataFrame is left unmodified.
        updated = dataset.copy()
        updated[column_name] = np.random.randint(
            min_value, max_value + 1, size=len(updated)
        )
        updated_datasets.append(updated)

    return updated_datasets
