from random import randint, seed
import pandas as pd
from sklearn.linear_model import LinearRegression

# Constants
TEAMS = ['Team A', 'Team B', 'Team C', 'Team D', 'Team E']
PENALTY_COST = 1000  # in dollars
MAX_GOALS_PER_MATCH = 5
MAX_PENALTIES_PER_MATCH = 3


def simulate_league(num_matches, rng_seed=None):
    """
    Simulate multiple football matches for a league involving multiple teams,
    generating random goals and penalties for each match. After simulating all
    matches, train a linear regression model to predict penalty costs from goals
    for each team.

    Parameters:
    - num_matches (int): Number of matches to simulate for each team.
    - rng_seed (int, optional): Seed for the random number generator to ensure
      reproducibility. Defaults to None.

    Returns:
    - tuple:
        - pd.DataFrame: Contains 'Team', 'Goals' (total goals across all matches),
          and 'Penalty Cost' (total penalty cost across all matches) columns,
          one row per team.
        - LinearRegression: Trained model to predict 'Penalty Cost' based on 'Goals'.

    Requirements:
    - pandas
    - sklearn.linear_model
    - random
    """
    if rng_seed is not None:
        seed(rng_seed)

    records = []
    for team in TEAMS:
        total_goals = 0
        total_penalties = 0
        for _ in range(num_matches):
            total_goals += randint(0, MAX_GOALS_PER_MATCH)
            total_penalties += randint(0, MAX_PENALTIES_PER_MATCH)
        records.append({
            'Team': team,
            'Goals': total_goals,
            'Penalty Cost': total_penalties * PENALTY_COST
        })

    df = pd.DataFrame(records)

    model = LinearRegression()
    model.fit(df[['Goals']], df['Penalty Cost'])

    return df, model
