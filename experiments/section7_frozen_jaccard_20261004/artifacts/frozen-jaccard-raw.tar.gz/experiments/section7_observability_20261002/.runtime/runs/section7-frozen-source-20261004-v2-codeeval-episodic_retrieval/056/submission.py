from matplotlib import pyplot as plt
from sklearn.decomposition import PCA
import numpy as np


def new_solution(arrays):
    """
    Performs Principal Component Analysis (PCA) on the sum of rows of each 2D
    numpy array in a list and plots the explained variance ratio for each array
    in subplots of a single figure.

    The title of each subplot is
    'Explained Variance Ratio of Principal Components for Array X',
    where X is the index of the array in the list.

    Parameters:
    - arrays (list): A list of 2D numpy arrays. The input data for PCA.

    Returns:
    - fig (matplotlib.figure.Figure): The figure object containing the subplots.

    Requirements:
    - scikit-learn
    - matplotlib
    - numpy

    Notes:
    - Only the first principal component is considered for each array.
    - Each subplot illustrates the proportion of the corresponding dataset's
      variance that lies along the axis of the first principal component.

    Example:
    >>> import numpy as np
    >>> arrays = [np.array([[i+j for i in range(3)] for j in range(5)])]
    >>> fig = new_solution(arrays)
    >>> fig.axes[0].get_title()
    'Explained Variance Ratio of Principal Components for Array 0'
    """
    n = len(arrays)
    fig, axes = plt.subplots(n, 1, squeeze=False)

    for i, arr in enumerate(arrays):
        # Sum along the rows (axis=1) to get one value per row of the input array
        row_sums = arr.sum(axis=1)

        # Reshape into a 2D array with a single feature so PCA can be applied
        data = row_sums.reshape(-1, 1)

        # Only the first principal component is considered
        pca = PCA(n_components=1)
        pca.fit(data)
        explained_variance_ratio = pca.explained_variance_ratio_

        ax = axes[i][0]
        ax.bar(range(1, len(explained_variance_ratio) + 1),
               explained_variance_ratio,
               color='steelblue', edgecolor='black')
        ax.set_xlabel('Principal Component')
        ax.set_ylabel('Explained Variance Ratio')
        ax.set_title(f'Explained Variance Ratio of Principal Components for Array {i}')

    fig.tight_layout()
    return fig
