import pandas as pd
import numpy as np


def generate_and_concat_dataframes(num_dataframes=3, rows_per_df=100, columns_per_df=3):
    """
    Generate multiple Pandas DataFrames, each with random alphabets in each cell,
    and concatenate them vertically to form a single large DataFrame.

    Parameters:
    - num_dataframes (int, optional): Number of DataFrames to generate. Defaults to 3.
    - rows_per_df (int, optional): Number of rows for each DataFrame. Defaults to 100.
    - columns_per_df (int, optional): Number of columns for each DataFrame. Defaults to 3.

    Returns:
    DataFrame: A single pandas DataFrame formed by vertically concatenating the
    generated DataFrames. Each column is named with a string from the list
    ['a', 'b', 'c', ...] depending on the number of columns specified.

    Requirements:
    - pandas
    - numpy

    Example:
    >>> df = generate_and_concat_dataframes(num_dataframes=2, rows_per_df=2, columns_per_df=3)
    >>> df.shape
    (4, 3)
    >>> list(df.columns)
    ['a', 'b', 'c']
    """
    alphabet = list('abcdefghijklmnopqrstuvwxyz')
    column_names = [chr(ord('a') + i) for i in range(columns_per_df)]

    dataframes = [
        pd.DataFrame(
            np.random.choice(alphabet, size=(rows_per_df, columns_per_df)),
            columns=column_names,
        )
        for _ in range(num_dataframes)
    ]

    return pd.concat(dataframes, ignore_index=True)
