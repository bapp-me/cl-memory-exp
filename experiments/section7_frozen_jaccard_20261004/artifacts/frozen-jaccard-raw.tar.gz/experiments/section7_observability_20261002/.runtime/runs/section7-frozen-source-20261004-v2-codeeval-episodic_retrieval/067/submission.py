import re
import hashlib
from collections import Counter

def new_solution(input_list):
    """
    Remove all special characters, punctuation marks, and spaces from each string in the
    input list (retaining only alphanumeric characters), hash each cleaned string with
    SHA256, and find the most common hash among them.

    Parameters:
    input_list (list of str): The list of strings to be cleaned and hashed.

    Returns:
    tuple: (list of str, str or None) - A list of SHA256 hex digests of the cleaned strings,
           and the most common hash among them (None if the list is empty).

    Requirements:
    - re
    - hashlib
    - collections.Counter

    Example:
    >>> new_solution(['hello world!', 'hello world!', 'abc'])
    (['936a185caaa266bb9cbe981e9e05cb78cd732b0b3280eb944412bb6f8f8f07af',
      '936a185caaa266bb9cbe981e9e05cb78cd732b0b3280eb944412bb6f8f8f07af',
      'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'],
     '936a185caaa266bb9cbe981e9e05cb78cd732b0b3280eb944412bb6f8f8f07af')
    """
    # Clean each string, keeping only alphanumeric characters, then hash with SHA256
    hashes = [
        hashlib.sha256(re.sub(r'[^a-zA-Z0-9]', '', s).encode()).hexdigest()
        for s in input_list
    ]

    # Determine the most common hash (None if the list is empty)
    most_common = Counter(hashes).most_common(1)[0][0] if hashes else None

    return hashes, most_common
