import numpy as np
from scipy import stats
import matplotlib.pyplot as plt


def analyze_process(mu=0, sigma=1, sample_size=1000, num_samples=5, seed=0):
    """
    Analyze the performance of a manufacturing process that produces parts
    following a normal distribution with a given mean (mu) and standard
    deviation (sigma).

    Multiple samples are generated from the distribution. For each sample,
    the empirical mean and standard deviation are calculated. Histograms of
    all samples are plotted together with the theoretical probability density
    function (PDF) of the normal distribution. The overall empirical mean and
    standard deviation across all samples are also calculated.

    Parameters:
    - mu (float): The mean of the normal distribution. Default is 0.
    - sigma (float): The standard deviation of the normal distribution. Default is 1.
    - sample_size (int): The size of each sample to generate. Default is 1000.
    - num_samples (int): The number of samples to generate. Default is 5.
    - seed (int): The seed for the random number generator (for reproducibility). Default is 0.

    Returns:
    - ax (matplotlib.axes._axes.Axes): Axes object with the plotted histograms
      and normal PDF, with the title format of
      'Normal Distribution with $\\mu = %0.2f, \\sigma = %0.2f$'.
    - list: The empirical means of each sample.
    - list: The empirical standard deviations of each sample.
    - float: The overall empirical mean across all samples.
    - float: The overall empirical standard deviation across all samples.

    Requirements:
    - numpy for data generation.
    - scipy.stats for statistical functions.
    - matplotlib.pyplot for plotting.

    Example:
    >>> ax, means, stds, overall_mean, overall_std = analyze_process(0, 1, 1000, 5)
    >>> type(ax)
    <class 'matplotlib.axes._axes.Axes'>
    >>> len(means), len(stds)
    (5, 5)
    """
    # Seed the random number generator for reproducibility
    np.random.seed(seed)

    fig, ax = plt.subplots()

    empirical_means = []
    empirical_stds = []
    all_samples = []

    # Range for the theoretical PDF curve (mu +/- 4 sigma)
    x = np.linspace(mu - 4 * sigma, mu + 4 * sigma, 1000)
    pdf = stats.norm.pdf(x, mu, sigma)

    # Generate each sample, compute its statistics, and plot histogram + PDF
    for _ in range(num_samples):
        sample = np.random.normal(mu, sigma, sample_size)
        empirical_means.append(sample.mean())
        empirical_stds.append(sample.std())
        all_samples.append(sample)

        ax.hist(sample, bins=30, density=True, alpha=0.6, edgecolor='black')
        ax.plot(x, pdf, 'r-', lw=2)

    # Overall empirical statistics across all samples combined
    combined = np.concatenate(all_samples)
    overall_mean = combined.mean()
    overall_std = combined.std()

    ax.set_title('Normal Distribution with $\\mu = %0.2f, \\sigma = %0.2f$' % (mu, sigma))
    ax.set_xlabel('Value')
    ax.set_ylabel('Density')

    return ax, empirical_means, empirical_stds, overall_mean, overall_std
