import numpy as np
from scipy.spatial import Voronoi, voronoi_plot_2d
import matplotlib.pyplot as plt


def new_solution(points):
    """
    Given a set of points in 2D space, divide the points into three equal parts,
    calculate the Voronoi diagram for each subset, and overlay all three
    Voronoi diagrams on a single plot to visualize their combined effect.

    Parameters:
    - points (array-like): An array of shape (n_points, 2) with the
      coordinates of the points.

    Returns:
    tuple (vors, ax): A tuple containing:
        - vors (list): A list of three scipy.spatial.Voronoi objects, one for
          each subset of points.
        - ax (matplotlib.axes.Axes): The axes of the plot showing the overlaid
          Voronoi diagrams of the three subsets.

    Raises:
    - ValueError: If points do not have shape (n_points, 2) or contain fewer
      than 3 points.
    """
    points = np.asarray(points, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError("points must have shape (n_points, 2)")
    if points.shape[0] < 3:
        raise ValueError("points must contain at least 3 points")

    # Divide the points into three (near-)equal parts
    subsets = np.array_split(points, 3)

    fig, ax = plt.subplots()
    vors = []
    colors = ['b', 'g', 'r']

    for i, subset in enumerate(subsets):
        vor = Voronoi(subset)
        vors.append(vor)
        voronoi_plot_2d(
            vor,
            ax=ax,
            show_points=True,
            show_vertices=False,
            line_colors=colors[i % len(colors)],
        )

    ax.set_title("Overlaid Voronoi Diagrams of Three Subsets")

    return vors, ax
