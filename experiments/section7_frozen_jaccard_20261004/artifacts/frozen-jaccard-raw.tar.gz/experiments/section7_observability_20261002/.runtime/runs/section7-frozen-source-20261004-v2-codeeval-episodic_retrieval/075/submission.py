import pandas as pd
import time

def process_documents(documents):
    """
    Processes a list of documents to find the most common word lengths in the
    'Content' field for each category.

    Parameters:
    documents (list of dict): Each dict has 'Title', 'Content', and 'Category' fields.

    Returns:
    dict: Keys are categories, values are dicts mapping word lengths to their
          respective counts for that category.

    Requirements:
    - pandas
    - time

    Example:
    >>> docs = [{'Title': 'T1', 'Content': 'hello world', 'Category': 'A'}]
    >>> process_documents(docs)
    {'A': {5: 2}}
    """
    if not documents:
        return {}

    start_time = time.time()

    # Convert the list of documents to a DataFrame
    df = pd.DataFrame(documents)

    result = {}
    for category, group in df.groupby('Category'):
        # Split the content into words and count the length of each word
        words = group['Content'].str.split().explode().dropna()
        lengths = words.str.len()
        counts = lengths.value_counts()
        result[category] = {int(k): int(v) for k, v in counts.items()}

    elapsed = time.time() - start_time  # timing per requirements import

    return result
