import collections
import string
import random

def combined_frequency(lengths, seed=0):
    """
    Generate multiple random strings of varying lengths using ASCII letters
    and calculate the combined frequency of each character across all generated strings.

    Parameters:
    lengths (list): A list of integers, each specifying the length of a random string to generate.
    seed (int, Optional): The seed to be used for the random number generator. Default is 0.

    Returns:
    dict: A dictionary with the frequency of each character across all generated strings.

    Requirements:
    - The function uses the 'collections', 'string', and 'random' modules from the Python standard library.
    - The generated strings consist only of ASCII letters.
    - The result is deterministic for a given seed.

    Example:
    >>> result = combined_frequency([5, 3, 4])
    >>> isinstance(result, dict)  # The result should be a dictionary
    True
    >>> all(key in string.ascii_letters for key in result.keys())  # All keys should be ASCII letters
    True
    >>> combined_frequency([5, 3, 4], 0) == combined_frequency([5, 3, 4], 0)  # Deterministic for a given seed
    True
    >>> sum(combined_frequency([5, 3, 4]).values())  # Total counts equal sum of lengths
    12
    """
    random.seed(seed)
    combined = []
    for length in lengths:
        combined.extend(random.choices(string.ascii_letters, k=length))
    return dict(collections.Counter(combined))
