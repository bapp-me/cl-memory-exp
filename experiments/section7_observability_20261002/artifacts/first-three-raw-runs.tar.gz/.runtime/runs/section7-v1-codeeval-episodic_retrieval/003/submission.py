import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']

def generate_report(datasets):
    """
    Generate a detailed category distribution report for multiple datasets.

    Parameters:
    datasets (list): A list of tuples, where each tuple contains the dataset
        name and a range (min, max) for the counts of categories.

    Returns:
    DataFrame: A pandas DataFrame with three columns: 'Dataset' (dataset name),
        'Category' (category names) and 'Count' (count of each category).

    Requirements:
    - pandas
    - random

    Example:
    >>> random.seed(0)
    >>> df = generate_report([('ds1', (0, 100)), ('ds2', (10, 20))])
    >>> list(df.columns)
    ['Dataset', 'Category', 'Count']
    >>> df['Count'][0] >= 0
    True
    """
    frames = []
    for name, value_range in datasets:
        counts = [random.randint(value_range[0], value_range[1]) for _ in CATEGORIES]
        frames.append(pd.DataFrame({'Dataset': name, 'Category': CATEGORIES, 'Count': counts}))
    if not frames:
        return pd.DataFrame(columns=['Dataset', 'Category', 'Count'])
    return pd.concat(frames, ignore_index=True)
