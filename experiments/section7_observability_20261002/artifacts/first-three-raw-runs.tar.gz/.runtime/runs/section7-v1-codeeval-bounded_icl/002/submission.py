import collections
import string
import random


def combined_frequency(lengths, seed=0):
    """
    Generate multiple random strings of the given lengths using ASCII letters
    and calculate the combined frequency of each character across all strings.

    Parameters:
    lengths (list): A list of integers, each specifying the length of a random
                    string to be generated.
    seed (int, Optional): The seed to be used for the random number generator.
                          Default is 0.

    Returns:
    dict: A dictionary with the combined frequency of each character across all
          generated strings.

    Requirements:
    - The function uses the 'collections', 'string', and 'random' modules from
      the Python standard library.
    - The generated strings consist only of ASCII letters.
    - The result is deterministic for a given seed.

    Example:
    >>> result = combined_frequency([5, 3])
    >>> isinstance(result, dict)  # The result should be a dictionary
    True
    >>> all(key in string.ascii_letters for key in result.keys())  # All keys should be ASCII letters
    True
    >>> sum(result.values())  # Total count equals the sum of all lengths
    8
    """
    # Initialize the random number generator for reproducibility
    random.seed(seed)

    combined_counter = collections.Counter()

    # Generate a random string for each requested length and accumulate counts
    for length in lengths:
        random_string = ''.join(random.choice(string.ascii_letters) for _ in range(length))
        combined_counter.update(random_string)

    return dict(combined_counter)
