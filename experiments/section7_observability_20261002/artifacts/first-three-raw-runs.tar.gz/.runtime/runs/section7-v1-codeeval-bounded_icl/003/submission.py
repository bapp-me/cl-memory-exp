import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']

def generate_report(datasets):
    """
    Generate a detailed category distribution report for multiple datasets.

    Each dataset is represented by a tuple containing its name and the range
    (min, max) for the counts of categories. Random counts are generated for
    each category within the specified range, and the results for all datasets
    are combined into a single DataFrame.

    Parameters:
    datasets (list): A list of tuples, where each tuple contains:
                     - name (str): The name of the dataset.
                     - value_range (tuple): A tuple (min, max) specifying the
                       range for generating random counts for the categories.

    Returns:
    DataFrame: A pandas DataFrame with three columns:
               'Dataset'  - the dataset name,
               'Category' - the category name,
               'Count'    - the generated count for that category.

    Requirements:
    - pandas
    - random

    Example:
    >>> df = generate_report([('ds1', (0, 100))])
    >>> list(df.columns)
    ['Dataset', 'Category', 'Count']
    >>> df['Count'][0] >= 0
    True
    """
    rows = []

    for name, value_range in datasets:
        min_val, max_val = value_range
        for category in CATEGORIES:
            count = random.randint(min_val, max_val)
            rows.append({'Dataset': name, 'Category': category, 'Count': count})

    df = pd.DataFrame(rows, columns=['Dataset', 'Category', 'Count'])
    return df
