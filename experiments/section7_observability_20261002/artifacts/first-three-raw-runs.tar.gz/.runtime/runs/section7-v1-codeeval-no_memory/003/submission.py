import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']


def generate_report(datasets):
    """
    Generate a detailed category distribution report for multiple datasets.

    Parameters
    ----------
    datasets : list
        A list of datasets, where each dataset is a tuple containing:
        - the dataset's name
        - the range for the counts of categories, given as a (low, high)
          pair of integers (inclusive).

    Returns
    -------
    pandas.DataFrame
        A DataFrame with three columns: 'Dataset', 'Category', and 'Count',
        combining the category distributions for all provided datasets.
    """
    rows = []
    for dataset in datasets:
        name, rng = dataset[0], dataset[1]
        if isinstance(rng, (tuple, list)) and len(rng) == 2:
            low, high = rng
        else:
            low = high = rng
        for category in CATEGORIES:
            rows.append({
                'Dataset': name,
                'Category': category,
                'Count': random.randint(low, high)
            })
    return pd.DataFrame(rows, columns=['Dataset', 'Category', 'Count'])
