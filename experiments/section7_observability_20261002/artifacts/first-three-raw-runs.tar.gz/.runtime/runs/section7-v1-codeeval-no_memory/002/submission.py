import collections
import string
import random


def combined_frequency(lengths, seed=0):
    """Generate random strings of the given lengths and return the combined
    character frequencies across all generated strings.

    Parameters
    ----------
    lengths : list of int
        The lengths of the random strings to generate.
    seed : int, optional
        Seed for the random number generator (default 0), ensuring
        reproducible results.

    Returns
    -------
    dict
        A dictionary mapping each character to its total frequency across
        all generated strings.
    """
    random.seed(seed)
    counter = collections.Counter()
    for length in lengths:
        s = ''.join(random.choice(string.ascii_lowercase) for _ in range(length))
        counter.update(s)
    return dict(counter)
