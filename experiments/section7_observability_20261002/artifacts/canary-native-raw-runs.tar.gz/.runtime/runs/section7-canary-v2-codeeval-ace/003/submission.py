import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']

def generate_report(datasets):
    """
    Generate a detailed category distribution report for multiple datasets.

    Each dataset is a tuple of (name, (min_count, max_count)). For every
    dataset, an independent random count is drawn (inclusive on both
    endpoints) for each category in CATEGORIES.

    Parameters
    ----------
    datasets : list of tuple
        Each tuple contains the dataset's name and a (min, max) range
        for the counts of categories.

    Returns
    -------
    pd.DataFrame
        A DataFrame with columns 'Dataset', 'Category', and 'Count',
        combining the category distributions for all datasets.
    """
    rows = []
    for name, (low, high) in datasets:
        for category in CATEGORIES:
            rows.append({
                'Dataset': name,
                'Category': category,
                'Count': random.randint(low, high)
            })
    return pd.DataFrame(rows, columns=['Dataset', 'Category', 'Count'])
