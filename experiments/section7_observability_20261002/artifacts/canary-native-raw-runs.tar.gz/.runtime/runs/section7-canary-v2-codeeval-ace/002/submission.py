import collections
import string
import random

def combined_frequency(lengths, seed=0):
    """
    Generate random strings of the given lengths and compute the combined
    frequency of each character across all generated strings.

    Parameters
    ----------
    lengths : list of int
        The lengths of the random strings to generate. One random string
        is generated for each entry in the list.
    seed : int, optional
        Seed for the random number generator (default is 0), ensuring
        reproducible results.

    Returns
    -------
    dict
        A dictionary mapping each character to its total frequency across
        all generated strings combined.
    """
    random.seed(seed)

    combined = []
    for length in lengths:
        combined.append(''.join(random.choice(string.ascii_letters) for _ in range(length)))

    combined_string = ''.join(combined)
    return dict(collections.Counter(combined_string))
