import collections
import string
import random


def combined_frequency(lengths, seed=0):
    """
    Generate multiple random strings of varying lengths and calculate the
    combined frequency of each character across all generated strings.

    Parameters
    ----------
    lengths : list of int
        Lengths of the random strings to generate.
    seed : int, optional
        Seed for the random number generator to ensure reproducibility
        (default 0).

    Returns
    -------
    dict
        Dictionary mapping each character to its total frequency across all
        generated strings.
    """
    random.seed(seed)
    alphabet = string.ascii_letters + string.digits
    combined = []
    for length in lengths:
        combined.extend(random.choice(alphabet) for _ in range(length))
    return dict(collections.Counter(combined))
