import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']

def generate_report(datasets):
    """
    Generate a category distribution report for multiple datasets.

    Parameters
    ----------
    datasets : list of tuple
        Each tuple contains (name, (low, high)), where (low, high) is the
        inclusive range from which each category's count is randomly drawn.

    Returns
    -------
    pd.DataFrame
        A DataFrame with columns 'Dataset', 'Category', and 'Count',
        combining the category distributions of all datasets.
    """
    rows = []
    for name, rng in datasets:
        low, high = rng
        for category in CATEGORIES:
            count = random.randint(low, high)
            rows.append({'Dataset': name, 'Category': category, 'Count': count})
    return pd.DataFrame(rows, columns=['Dataset', 'Category', 'Count'])
