import collections
import string
import random


def combined_frequency(lengths, seed=0):
    """
    Generate multiple random strings of the given lengths using the provided
    seed, then compute the combined frequency of each character across all
    the generated strings.

    Args:
        lengths: A list (or iterable) of integer lengths; one random string
                 is generated for each length.
        seed:    Seed for the random generator, ensuring reproducible output.

    Returns:
        A dict mapping each character to its total number of occurrences
        across all generated strings.
    """
    # Use a dedicated Random instance so global random state is untouched
    # and results are reproducible for a given seed.
    rng = random.Random(seed)

    combined_parts = []
    for length in lengths:
        combined_parts.append(
            ''.join(rng.choice(string.ascii_lowercase) for _ in range(length))
        )

    combined = ''.join(combined_parts)
    return dict(collections.Counter(combined))
