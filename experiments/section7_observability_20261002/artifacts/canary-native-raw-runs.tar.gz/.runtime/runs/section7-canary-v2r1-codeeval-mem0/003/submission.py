import pandas as pd
import random

# Constants
CATEGORIES = ['A', 'B', 'C', 'D', 'E']

def generate_report(datasets):
    """
    Generate a combined category distribution report for multiple datasets.

    Parameters
    ----------
    datasets : list of tuples
        Each tuple contains (dataset_name, range) where range is a tuple
        (min_count, max_count) used to randomly generate category counts.

    Returns
    -------
    pandas.DataFrame
        A DataFrame with columns 'Dataset', 'Category', and 'Count',
        combining the category distributions of all provided datasets.
    """
    rows = []
    for name, count_range in datasets:
        lo, hi = count_range
        # Guard against reversed ranges
        if lo > hi:
            lo, hi = hi, lo
        for category in CATEGORIES:
            count = random.randint(lo, hi)
            rows.append({'Dataset': name, 'Category': category, 'Count': count})
    return pd.DataFrame(rows, columns=['Dataset', 'Category', 'Count'])
